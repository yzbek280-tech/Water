#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/charObfuscate.h"
#include "Includes/Utils.h"
#include "includes/Dobby/dobby.h"
#include "includes/Hooks.h"
#include "imgui.h"
#include "imgui_internal.h"
#include "ImGui/Font/icons.h"
#include "ImGui/Font/Roboto-Regular.h"
#include "backends/imgui_impl_opengl3.h"
#include "backends/imgui_impl_android.h"
#include "ImGui/user_interface.cpp"
namespace Offsets {
    uintptr_t clientPlayerList = 0x10;
    uintptr_t lastTickPosition = 0x1C8;
    uintptr_t health = 0x124;
}
int glHeight, glWidth;
bool setup;
void SetupImgui() {
// Setup Dear ImGui context
IMGUI_CHECKVERSION();
ImGui::CreateContext();
ImGuiIO& io = ImGui::GetIO(); (void)io;
ImGui::StyleColorsDark();
ImGuiStyle &style = ImGui::GetStyle();
auto& Style = ImGui::GetStyle();
Style.Colors[ImGuiCol_WindowBg] = ImVec4(0.098f, 0.086f, 0.161f, 0.941f);
Style.Colors[ImGuiCol_CheckMark] = ImVec4(0.455f, 0.392f, 0.878f, 1.000f);
Style.Colors[ImGuiCol_FrameBg] = ImVec4(0.455f, 0.392f, 0.878f, 0.541f);
Style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.334f, 0.291f, 0.628f, 0.541f);
Style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.334f, 0.291f, 0.628f, 0.541f);
Style.Colors[ImGuiCol_Header] = ImVec4(0.455f, 0.392f, 0.878f, 0.541f);
Style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.334f, 0.291f, 0.628f, 0.541f);
Style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.334f, 0.291f, 0.628f, 0.541f);
Style.Colors[ImGuiCol_SliderGrab] = ImVec4(1.000f, 1.000f, 1.000f, 1.000f);
Style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(1.000f, 1.000f, 1.000f, 1.000f);
io.DisplaySize = ImVec2((float)glWidth, (float)glHeight);
// Setup Dear ImGui style
// Our state
io.Fonts->ClearFonts();
ImFontConfig font_cfg;
font_cfg.SizePixels = 20.0f;
font_cfg.GlyphRanges = io.Fonts->GetGlyphRangesCyrillic();
//buttonsmenu = io.Fonts->AddFontFromMemoryTTF(Roboto_Regular, sizeof Roboto_Regular, 20.0f, &font_cfg);
io.Fonts->AddFontFromMemoryTTF(Roboto_Regular, sizeof Roboto_Regular, 15.0f, &font_cfg);
tabs = io.Fonts->AddFontFromMemoryTTF(Roboto_Regular, sizeof Roboto_Regular, 15.0f, &font_cfg);

      
ImFontConfig font_cfg2;
font_cfg2.MergeMode = true;
static const ImWchar icon_ranges[] = {ICON_MIN_FA, ICON_MAX_FA, 0x0};
icfont = io.Fonts->AddFontFromMemoryCompressedBase85TTF(FontAwesome6_compressed_data_base85, 15.0f, &font_cfg2, icon_ranges);
ImVec4 clear_color = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
// Setup Platform/Renderer backends
ImGui_ImplOpenGL3_Init(_("#version 100"));
// We load the default font with increased size to improve readability on many devices with "high" DPI.
// Arbitrary scale-up
ImGui::GetStyle().ScaleAllSizes(2.3f);
}
bool isLogin = false; // За замовчуванням false — показує вікно логіну
static bool MenDeal = true;
ImVec4 Esp_NC = ImVec4(1,1,1,1);
ImColor bordercolor = ImColor(62,14,185,200);
ImColor bgcolor = ImColor(42,6,108,100);
ImVec4 visibleCol = ImColor(0,255,0);
ImVec4 invisibleCol = ImColor(255,0,0);
bool watermark = true;
void DrawWatermark() {
    if (watermark) {
        std::string namestring = "@WaterHack1";
        ImGuiIO& io = ImGui::GetIO();
        std::string watertext = std::string(_("@WaterHack1"));;
        watertext += std::string(_(" | "));
        watertext += namestring;

        auto textsize = 15;
        auto height = 0;
        auto textSizeX = ((ImGui::CalcTextSize(watertext.c_str()).x) / ImGui::GetFontSize()) * textsize;

        ImVec2 rectMin(20, 30 + height);
        ImVec2 rectMax(-40 + 80 + textSizeX, 65 - 10);

        ImGui::GetForegroundDrawList()->AddRectFilled(rectMin, rectMax, bgcolor, 0, 0);
        ImGui::GetForegroundDrawList()->AddLine(ImVec2(rectMin.x, rectMax.y), ImVec2(rectMax.x, rectMax.y), bordercolor, 2);
        ImGui::GetForegroundDrawList()->AddText(ImGui::GetFont(), textsize, ImVec2(30, (25 + 20 - (((ImGui::CalcTextSize(watertext.c_str()).y / 2) / ImGui::GetFontSize()) * textsize) + height) - 3), ImColor(255, 255, 255), watertext.c_str());
    }
}
static int selected = 0;
static int sub_selected = 0;
void features(int type)
{   

    if(type == 0){
    ImGui::Checkbox(_("Esp box"), &espbox);
    ImGui::Checkbox(_("Esp health"), &esphealth);
    }

    if (type == 2){            
    }

    if(type == 3){
    }

    if(type == 4){
    }

    if (type == 6){       
    }

    if (type == 7){
    }

    if (type == 8){
    }

    if (type == 9){
    }

    if (type == 10) {
    }

    if(type == 12){
    }

    if(type == 13){
    }

    if(type == 14){
    }

    if (type == 15){
    }

    if(type == 16){
    }
}

void imgui_source() {
                ImGui::SetNextWindowSize(ImVec2(800,500), ImGuiCond_FirstUseEver);
                ImGui::Begin("AquaCheats | Test build", nullptr, ImGuiWindowFlags_NoDecoration);

                auto draw = ImGui::GetWindowDrawList();

                ImGui::GetStyle().WindowPadding = ImVec2(0,0);
                ImVec2 pos = ImGui::GetWindowPos();
                ImVec2 size = ImGui::GetWindowSize();
                draw->AddRectFilled(ImVec2(pos.x - 100, pos.y), ImVec2(pos.x + 65, pos.y + size.y), ImColor(13, 10, 27, 255));

                ImGui::SetCursorPos(ImVec2(20, 30));
                ImGui::Text("FLEX");
                
                ImGui::SetCursorPos(ImVec2(25, 70));
                ImGui::BeginGroup();
                if (custom_interface::tab(ICON_FA_EYE, _("VISUALS"), 1 == selected, 0, 0, -15, 25)) {
                    selected = 1;
                }
                
                if (custom_interface::tab(ICON_FA_HOUSE_CHIMNEY, _("MAIN"), 2 == selected, 0, 0, -8, 25)) {
                    selected = 2;
                }
                
                if (custom_interface::tab(ICON_FA_GEAR, _("OTHER"), 3 == selected, 1, 0, -12, 25)) {
                    selected = 3;
                }
                
                if (custom_interface::tab(ICON_FA_PAINTBRUSH, _("SKINS"), 4 == selected, 0, 0, -10, 25)) {
                    selected = 4;
                }
                ImGui::EndGroup();

                if (selected == 1){

                    ImGui::SetCursorPos(ImVec2(80,12));
                    ImGui::BeginGroup();
                    if(custom_interface::subtab(_("Esp"), 1 == sub_selected)){
                        sub_selected = 1;
                    }

                    ImGui::SameLine();
                    if(custom_interface::subtab(_("Other"), 2 == sub_selected)){
                        sub_selected = 2;
                    }

                    ImGui::EndGroup();

                        if(sub_selected == 1){
                            ImGui::SetCursorPos(ImVec2(80, 60));
                            ImGui::BeginChild(_("Esp"), ImVec2(160,290));
                            { 
                                if(ImGui::Button("Close menu")) MenDeal = !MenDeal;
                                features(0);
                            }
                            ImGui::EndChild();

                            ImGui::SetCursorPos(ImVec2(255, 60));
                            ImGui::BeginChild(_("Preview"), ImVec2(160,290));
                            {
                                if (espbox) {
                                    ImGui::SetCursorPos(ImVec2(140, 200));
                                    ImVec2 pos1 = ImGui::GetCursorScreenPos();
                                    draw->AddRect(ImVec2(pos1.x - 110, pos1.y - 155), ImVec2(pos1.x - 10, pos1.y + 35), ImColor(invisibleCol.x, invisibleCol.y, invisibleCol.z, 0.8f), espround,0,espstroke);
                                }
                                if (espfill) {
                                    ImGui::SetCursorPos(ImVec2(140, 200));
                                    ImVec2 pos1 = ImGui::GetCursorScreenPos();
                                    draw->AddRectFilledMultiColor(ImVec2(pos1.x - 110, pos1.y - 155), ImVec2(pos1.x - 10, pos1.y + 35), 
                                        ImColor((int) (invisibleCol.x * 255),
                                                (int) (invisibleCol.y * 255),
                                                (int) (invisibleCol.z * 255),
                                                (int) ((float) (espgradient ? 10
                                                                            : 80) *
                                                       (float) espfillp / 100.0f)),
                                        ImColor((int) (invisibleCol.x * 255),
                                                (int) (invisibleCol.y * 255),
                                                (int) (invisibleCol.z * 255),
                                                (int) ((float) (espgradient ? 10
                                                                            : 80) *
                                                       (float) espfillp / 100.0f)),
                                        ImColor((int) (invisibleCol.x * 255),
                                                (int) (invisibleCol.y * 255),
                                                (int) (invisibleCol.z * 255),
                                                (int) (80.0f * (float) espfillp /
                                                       100.0f)),
                                        ImColor((int) (invisibleCol.x * 255),
                                                (int) (invisibleCol.y * 255),
                                                (int) (invisibleCol.z * 255),
                                                (int) (80.0f * (float) espfillp /
                                                       100.0f)));           }
                                if (esphealth) {
                                    ImGui::SetCursorPos(ImVec2(140, 200));
                                    ImVec2 pos1 = ImGui::GetCursorScreenPos();
                                    draw->AddRectFilled(ImVec2(pos1.x - 125, pos1.y - 155), ImVec2(pos1.x - 120, pos1.y + 35),
                                        ImColor(150, 255, 100, 255));
                                        
                                }
                                if (esparm) {
                                    ImGui::SetCursorPos(ImVec2(140, 140));
                                    ImVec2 pos1 = ImGui::GetCursorScreenPos();
                                    draw->AddText(
                                    ImGui::GetFont(),
                                    ImGui::GetFontSize() + esphptextsize,
                                    ImVec2(pos1.x - 10, pos1.y - 80),
                                    ImColor(66, 188, 245, 255),
                                    "100a");                
                                }
                                if (espname) {
                                    ImGui::SetCursorPos(ImVec2(140, 140));
                                    ImVec2 pos1 = ImGui::GetCursorScreenPos();
                                    draw->AddText(ImVec2(pos1.x - 95, pos1.y - 115), ImColor(Esp_NC.x, Esp_NC.y, Esp_NC.z), "propaganda");
                                }
                                if (espweapon) {
                                    ImGui::SetCursorPos(ImVec2(135, 140));
                                    ImVec2 pos1 = ImGui::GetCursorScreenPos();
                                    draw->AddText(ImVec2(pos1.x - 65, pos1.y + 105), ImColor(Esp_NC.x, Esp_NC.y, Esp_NC.z), "akr");
                                }             
                            }
                            ImGui::EndChild();
                        }

                        if(sub_selected == 2){
                            ImGui::SetCursorPos(ImVec2(80, 60));
                            ImGui::BeginChild(_("Other"), ImVec2(345,290));
                            {
                                features(2);
                            }
                            ImGui::EndChild();
                        }
                }

                if (selected == 2){

                    ImGui::SetCursorPos(ImVec2(80,12));
                    ImGui::BeginGroup();
                    if(custom_interface::subtab(_("Legit"), 1 == sub_selected)){
                        sub_selected = 1;
                    }
                    ImGui::SameLine();
                    if(custom_interface::subtab(_("Rage"), 2 == sub_selected)){
                        sub_selected = 2;
                    }
                    ImGui::EndGroup();

                        if(sub_selected == 1){
                            ImGui::SetCursorPos(ImVec2(80,60));
                            ImGui::BeginChild(_("Silent"), ImVec2(160,290));
                            {
                                features(3);
                            }
                            ImGui::EndChild();

                            ImGui::SetCursorPos(ImVec2(255, 60));
                            ImGui::BeginChild(_("Aimbot"), ImVec2(160,290));
                            {
                                features(4);
                                ImGui::Spacing();
                            }
                            ImGui::EndChild();
                        }

                        if(sub_selected == 2){
                            ImGui::SetCursorPos(ImVec2(80,60));
                            ImGui::BeginChild(_("Anti-Aim"), ImVec2(160,290));
                            {
                                features(6);
                            }
                            ImGui::EndChild();

                            ImGui::SetCursorPos(ImVec2(255, 60));
                            ImGui::BeginChild(_("Weapon"), ImVec2(160,130));
                            {
                                features(7);
                                ImGui::Spacing();
                            }
                            ImGui::EndChild();


                            ImGui::SetCursorPos(ImVec2(255, 210));
                            ImGui::BeginChild(_("Me and Enemy"), ImVec2(160,140));
                            {
                                features(8);
                                ImGui::Spacing();
                            }
                            ImGui::EndChild();
                        }
                } 

                if (selected == 3){

                    ImGui::SetCursorPos(ImVec2(80,12));
                    ImGui::BeginGroup();
                    if(custom_interface::subtab(_("Other"), 1 == sub_selected)){
                        sub_selected = 1;
                    }
                    ImGui::EndGroup();

                        if(sub_selected == 1){
                            ImGui::SetCursorPos(ImVec2(80, 60));
                            ImGui::BeginChild(_("Main"), ImVec2(160,290));
                            {
                                features(9);
                                ImGui::Spacing();
                            }
                            ImGui::EndChild();

                            ImGui::SetCursorPos(ImVec2(255, 60));
                            ImGui::BeginChild(_("Stats"), ImVec2(160,100));
                            {
                                features(10);
                                ImGui::Spacing();
                            }
                            ImGui::EndChild();

                            ImGui::SetCursorPos(ImVec2(255, 175));
                            ImGui::BeginChild(_("Profile"), ImVec2(160,175));
                            {
                                ImGui::Text("Soon");
                                ImGui::Spacing();
                            }
                            ImGui::EndChild();
                        }
                }

                if (selected == 4){
                
                    ImGui::SetCursorPos(ImVec2(80,12));
                    ImGui::BeginGroup();
                    if(custom_interface::subtab(_("Skins"), 1 == sub_selected)){
                        sub_selected = 1;
                    }

                    ImGui::SameLine();
                    if(custom_interface::subtab(_("Stickers"), 2 == sub_selected)){
                        sub_selected = 2;
                    }
                    ImGui::EndGroup();


                        if(sub_selected == 1){
                            ImGui::SetCursorPos(ImVec2(80, 60));
                            ImGui::BeginChild(_("Weapons"), ImVec2(160, 290));
                            {
                                features(12);
                                ImGui::Spacing();
                            }
                            ImGui::EndChild();
                            
                            ImGui::SetCursorPos(ImVec2(255, 60));
                            ImGui::BeginChild(_("Gloves"), ImVec2(160,65));
                            {
                                features(13);
                                ImGui::Spacing();
                            }
                            ImGui::EndChild();
                            
                            ImGui::SetCursorPos(ImVec2(255, 155));
                            ImGui::BeginChild(_("Knifes"), ImVec2(160,65));
                            {
                                features(14);
                                ImGui::Spacing();
                            }
                            ImGui::EndChild();
                            
                            ImGui::SetCursorPos(ImVec2(255, 250));
                            ImGui::BeginChild(_("Charms"), ImVec2(160,100));
                            {
                                features(15);
                                ImGui::Spacing();
                            }
                            ImGui::EndChild();
                        }

                        if(sub_selected == 2){
                            ImGui::SetCursorPos(ImVec2(80,60));
                            ImGui::BeginChild(_("Stickers"), ImVec2(345,290));
                            {
                                features(16);
                            }
                            ImGui::EndChild();
                        }
                }
                ImGui::End();
}

EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
    if (!setup) {
        SetupImgui();
        setup = true;
    }
    ImGuiIO &io = ImGui::GetIO();
    // Start the Dear ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
        ImGui::NewFrame();
    
    // Вставляємо підключення файлу логіну
    #include "login.cpp"

    // Головне меню та функції спрацюють тільки після успішного входу
    if (isLogin) {
        imgui_source();
        DrawWatermark();
        DrawESP();
    }
    ImGui::EndFrame();
    ImGui::Render();
    glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    return old_eglSwapBuffers(dpy, surface);
}
#define HOOKAF(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)

HOOKAF(void, Input, void *thiz, void *ex_ab, void *ex_ac) {
    origInput(thiz, ex_ab, ex_ac);
    ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz);
    return;
}
void *cheat(void *) {
    do {
    sleep(1);
    } while (!isLibraryLoaded(_("libil2cpp.so")));
    auto addr = (uintptr_t) dlsym(RTLD_NEXT, (_("eglSwapBuffers")));
    DobbyHook((void *) addr, (void *) hook_eglSwapBuffers, (void **) &old_eglSwapBuffers);
    return NULL;
}
__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
        void *sym_input = DobbySymbolResolver(("/system/lib/libinput.so"), ("_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE"));
    if (NULL != sym_input) {
        DobbyHook((void *)sym_input, (void *) myInput, (void **)&origInput);
    }
    pthread_t ptid;
    pthread_create(&ptid, NULL, cheat, NULL);
}
