    
    if (!isLogin) {
        static bool cache_loaded = false;
        if (!cache_loaded) {
            std::string cached_key = LoadKeyCache();
            if (!cached_key.empty()) {
                strcpy(s, cached_key.c_str());
            }
            cache_loaded = true;
        }
        
        ImVec2 center = ImGui::GetMainViewport()->GetCenter();
        ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
        ImGui::SetNextWindowSize(ImVec2(500, 680));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 25.0f);
        ImGui::PushStyleColor(ImGuiCol_WindowBg, IM_COL32(18, 15, 28, 200));
        
        if (ImGui::Begin(OBFUSCATE(""), 0, ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar)) {

            ImGuiWindow* win = ImGui::GetCurrentWindow();
            ImDrawList* dl = win->DrawList;
            ImVec2 win_pos = ImGui::GetWindowPos();
            ImVec2 win_size = ImGui::GetWindowSize();
            
           
            ImU32 glow_tl = ImGui::ColorConvertFloat4ToU32(ImVec4(0.28f, 0.12f, 0.48f, 0.25f));
            ImU32 glow_br = ImGui::ColorConvertFloat4ToU32(ImVec4(0.05f, 0.05f, 0.10f, 0.15f));
            dl->AddRectFilledMultiColor(win_pos, win_pos + win_size, glow_tl, glow_br, glow_br, glow_tl);
            
            
            ImU32 accent_col = ImGui::ColorConvertFloat4ToU32(ImVec4(0.68f, 0.40f, 0.98f, 1.00f));
            ImU32 border_col = ImGui::ColorConvertFloat4ToU32(ImVec4(0.20f, 0.18f, 0.28f, 0.6f));
            dl->AddRect(win_pos, win_pos + win_size, border_col, 25.0f, 0, 1.5f);
            
            float pad = 30.0f;
            ImVec2 content_pos = win_pos + ImVec2(pad, pad);
            float content_w = win_size.x - pad * 2;
            
            
            ImVec2 title_sz = ImGui::CalcTextSize("AUTHORIZATION");
            float title_x = (content_w - title_sz.x) * 0.5f;
            dl->AddText(content_pos + ImVec2(title_x, 0), IM_COL32(248, 248, 248, 255), "AUTHORIZATION");
            
         
            float line_y = content_pos.y + 35.0f;
            float line_w = 50.0f;
            float line_x = content_pos.x + (content_w - line_w) * 0.5f;
            dl->AddLine(ImVec2(line_x, line_y), ImVec2(line_x + line_w, line_y), accent_col, 2.5f);
            

            dl->AddText(content_pos + ImVec2(0, 60.0f), IM_COL32(150, 150, 160, 200), "Enter your license key to access cheat");
            

            dl->AddText(content_pos + ImVec2(0, 120.0f), accent_col, "LICENSE KEY");
            

            ImVec2 input_pos = content_pos + ImVec2(0, 155.0f);
            ImVec2 input_size = ImVec2(content_w, 55.0f);
            ImU32 input_bg = IM_COL32(35, 30, 50, 150);
            dl->AddRectFilled(input_pos, input_pos + input_size, input_bg, 15.0f);
            dl->AddRect(input_pos, input_pos + input_size, ImGui::ColorConvertFloat4ToU32(ImVec4(0.30f, 0.25f, 0.45f, 0.4f)), 15.0f, 0, 1.0f);
            

            ImGui::SetCursorPos(ImVec2(pad + 15.0f, 155.0f + pad + 10.0f));
            ImGui::PushItemWidth(content_w - 30.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);
            ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(0, 0, 0, 0));
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(248, 248, 248, 255));
            

            static bool b_show_key = false;
            ImGuiInputTextFlags input_flags = 0;
            if (!b_show_key) {
                input_flags |= ImGuiInputTextFlags_Password;
            }
            ImGui::InputTextWithHint("##key", "Enter your key here...", s, sizeof(s), input_flags);
            
            ImGui::PopStyleColor(2);
            ImGui::PopStyleVar();
            ImGui::PopItemWidth();
            

            ImGui::SetCursorPos(ImVec2(pad, 245.0f + pad));
            ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 12.0f);
            ImGui::PushStyleColor(ImGuiCol_Button, ImGui::ColorConvertFloat4ToU32(ImVec4(0.30f, 0.20f, 0.50f, 0.6f)));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImGui::ColorConvertFloat4ToU32(ImVec4(0.50f, 0.30f, 0.75f, 0.8f)));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImGui::ColorConvertFloat4ToU32(ImVec4(0.68f, 0.40f, 0.98f, 1.0f)));
            
            if (ImGui::Button("PASTE KEY", ImVec2(content_w, 50.0f))) {
                auto key = getClipboardText();
                strcpy(s, key.c_str());
            }
            
            ImGui::PopStyleColor(3);
            ImGui::PopStyleVar();
            

            static bool b_remember = false;
            

            ImGui::SetCursorPos(ImVec2(pad, 320.0f + pad));
            ImVec2 toggle_pos = ImGui::GetCursorScreenPos();
            float toggle_w = 50.0f;
            float toggle_h = 28.0f;
            ImRect toggle_bb(toggle_pos, toggle_pos + ImVec2(toggle_w, toggle_h));
            ImGui::ItemSize(toggle_bb);
            ImGui::ItemAdd(toggle_bb, ImGui::GetID("remember_toggle"));
            
            if (ImGui::IsMouseHoveringRect(toggle_bb.Min, toggle_bb.Max) && ImGui::IsMouseClicked(0)) 
                b_remember = !b_remember;
            
            ImU32 toggle_bg = b_remember ? accent_col : IM_COL32(60, 60, 80, 200);
            dl->AddRectFilled(toggle_bb.Min, toggle_bb.Max, toggle_bg, 15.0f);
            float knob_x = b_remember ? (toggle_bb.Max.x - toggle_h * 0.6f) : (toggle_bb.Min.x + toggle_h * 0.2f);
            dl->AddCircleFilled(ImVec2(knob_x, toggle_bb.GetCenter().y), toggle_h * 0.35f, IM_COL32(255, 255, 255, 255));
            dl->AddText(toggle_pos + ImVec2(toggle_w + 15.0f, 3.0f), IM_COL32(180, 180, 190, 200), "Remember key");
            

            ImVec2 show_key_pos = toggle_pos + ImVec2(content_w * 0.5f, 0);
            ImRect toggle_bb2(show_key_pos, show_key_pos + ImVec2(toggle_w, toggle_h));
            ImGui::ItemSize(toggle_bb2);
            ImGui::ItemAdd(toggle_bb2, ImGui::GetID("show_key_toggle"));
            
            if (ImGui::IsMouseHoveringRect(toggle_bb2.Min, toggle_bb2.Max) && ImGui::IsMouseClicked(0)) 
                b_show_key = !b_show_key;
            
            ImU32 toggle_bg2 = b_show_key ? accent_col : IM_COL32(60, 60, 80, 200);
            dl->AddRectFilled(toggle_bb2.Min, toggle_bb2.Max, toggle_bg2, 15.0f);
            float knob_x2 = b_show_key ? (toggle_bb2.Max.x - toggle_h * 0.6f) : (toggle_bb2.Min.x + toggle_h * 0.2f);
            dl->AddCircleFilled(ImVec2(knob_x2, toggle_bb2.GetCenter().y), toggle_h * 0.35f, IM_COL32(255, 255, 255, 255));
            dl->AddText(show_key_pos + ImVec2(toggle_w + 15.0f, 3.0f), IM_COL32(180, 180, 190, 200), "Show key");
            

            ImGui::SetCursorPos(ImVec2(pad, 395.0f + pad));
            ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 15.0f);
            ImGui::PushStyleColor(ImGuiCol_Button, accent_col);
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImGui::ColorConvertFloat4ToU32(ImVec4(0.78f, 0.50f, 1.00f, 1.00f)));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImGui::ColorConvertFloat4ToU32(ImVec4(0.60f, 0.35f, 0.90f, 1.00f)));
            
            if (ImGui::Button("LOGIN TO WIREX", ImVec2(content_w, 60.0f))) {
if (strcmp(s, "09.26.2026") == 0) {
    err = "OK";
    bValid = true;
    if (b_remember) {
        SaveKeyCache(s);
    } else {
        DeleteKeyCache();
    }
    isLogin = true;
} else {
    err = "Wrong Key!";
    isLogin = false;
}

            }
            
            ImGui::PopStyleColor(3);
            ImGui::PopStyleVar();
            
            ImVec2 bottom_boxes_y = content_pos + ImVec2(0, 490.0f);
            
            ImVec2 box1_pos = bottom_boxes_y;
            ImVec2 box1_size = ImVec2(content_w, 55.0f);
            ImU32 box_bg = IM_COL32(30, 25, 45, 180);
            dl->AddRectFilled(box1_pos, box1_pos + box1_size, box_bg, 12.0f);
            dl->AddRect(box1_pos, box1_pos + box1_size, ImGui::ColorConvertFloat4ToU32(ImVec4(0.25f, 0.20f, 0.40f, 0.5f)), 12.0f, 0, 1.0f);
            dl->AddCircleFilled(box1_pos + ImVec2(25.0f, 27.5f), 8.0f, accent_col);
            dl->AddText(box1_pos + ImVec2(50.0f, 15.0f), IM_COL32(248, 248, 248, 255), "TGK @WIREX_MOD");
            
            ImGui::ItemSize(ImRect(box1_pos, box1_pos + box1_size));
            ImGui::ItemAdd(ImRect(box1_pos, box1_pos + box1_size), ImGui::GetID("channel_box"));
            if (ImGui::IsMouseHoveringRect(box1_pos, box1_pos + box1_size) && ImGui::IsMouseClicked(0)) {
                OpenURL("https://t.me/WirexCL");
            }
            
            if (!err.empty() && err != "OK") {
                ImVec2 err_pos = content_pos + ImVec2(0, 620.0f);
                dl->AddText(err_pos, IM_COL32(255, 100, 100, 255), ("Error: " + err).c_str());
            } else if (err == "OK") {
                ImVec2 ok_pos = content_pos + ImVec2(0, 620.0f);
                dl->AddText(ok_pos, IM_COL32(100, 255, 100, 255), "Login Successful!");
            }
        }
        ImGui::End();
        ImGui::PopStyleColor();
        ImGui::PopStyleVar();
    }