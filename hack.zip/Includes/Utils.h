#ifndef UTILS
#define UTILS
#include <jni.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <cstdlib>
#include "Logger.h"
typedef unsigned long DWORD;
static uintptr_t libBase;
const char* libName = OBFUSCATE("libil2cpp.so");
bool libLoaded = false;
jboolean isGameLibLoaded(JNIEnv *env, jobject thiz) {
    return libLoaded;
}
bool isLibraryLoaded(const char *libraryName) {
    //libLoaded = true;
    char line[512] = {0};
    FILE *fp = fopen(OBFUSCATE("/proc/self/maps"), OBFUSCATE("rt"));
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            std::string a = line;
            if (strstr(line, libraryName)) {
                libLoaded = true;
                return true;
            }
        }
        fclose(fp);
    }
    return false;
}
#endif
